var express = require('express');
var path = require('path');
var router = express.Router();
var mysql = require('mysql');


var connection = mysql.createConnection( {
  //properties
  host:'localhost',
  user: 'root',
  password: '',
  database: 'the_spoon'
});

/* GET home page. */
router.get('/', function(req, res, next) {
  res.render('index', { title: 'Express' });
});

router.get('/listing', function(req, resp){


  //about mysql
  connection.query("SELECT Name, locations, phone_number, email_address FROM Restaurant", function(error, rows, fields){
    if(!!error){
      console.log('Error in the query');
    }else {
      console.log('Successful query'); 
      console.log(rows);
      resp.json(rows);
      
    }
  });


});

router.post('/results.json', function(req, res, next) {

  var cuisine = req.body.cuisine
  var location = req.body.location


var query ="SELECT Name, locations, phone_number, email_address, cuisine FROM Restaurant WHERE cuisine LIKE ?";

  connection.query(query,[cuisine], function(error, rows, fields){
    if(!!error){
      console.log('Error in the query');
    }else {
      console.log('Successful query'); 
      console.log(rows);
      res.json(rows);
    }


  });
});




router.post('/submit-login', function(req, res,next) {
  req.pool.getConnection(function(err,connection)
  {

    if(err)
    {
      res.sendStatus(402);
      console.log(err.message)
    }

    var query = "SELECT first_name FROM Customer WHERE email_address = ? AND password = SHA2(?, 256)";
    //var query = "SELECT first_name FROM Customer WHERE email_address = ? AND password = ?";

    connection.query(query,[req.body.email, req.body.pass], function(err, rows, fields)
    {
      connection.release(); //release connection
      console.log(rows);

      if(rows.length>0)
      {
        req.session.userid = rows[0].first_name;
        res.send(rows[0].first_name);
      }

      else
      {
        res.sendStatus(403);
      }

    });



  });

  //req.pool.getConnection

  //res.redirect('/index.html')

});





router.post('/submit-booking', (req, res) => {

  const bookingdate = req.body.bookingdate
  const numSeats = req.body.numSeats

  
  console.log('date: ' + req.body.bookingdate);
 
   console.log('number of Seats: ' + req.body.numSeats);

  

  res.send(" date: "+ bookingdate+ " Number of seats " + numSeats)

});

router.post('/submit-review', (req, res) => {

  const review = req.body.review
  
 
   console.log('Review: ' + req.body.review);  

  res.send(" Review: "+ review)

});

/*
router.post('/submit-register', (req, res, next) => {


  const  firstname= req.body.firstname
  const lastname = req.body.lastname
  const  Email1= req.body.Email1
  const password = req.body.password
  const password_confirm = req.body.password_confirm

  connection.query("INSERT INTO Customer (first_name, last_name, password, email_address) VALUES ('"+req.body.firstname+"','"+req.body.lastname+"','"+ req.body.password +"','"+req.body.Email1+"')",function(err, result)      
{                                                      
  if (err)
     throw err;
});

  res.redirect('/index.html')
});

//SHA2('req.body.password',256)
*/

router.post('/submit-register', function(req, res, next) {

  req.pool.getConnection(function(err,connection)
  {

    if(err)
    {
      res.sendStatus(402);
      console.log(err.message)
    }

  
  var query = "INSERT INTO Customer(first_name, last_name, email_address, password) VALUES (?, ? , ?, SHA2(?,256))";

//SHA2(?,256)

  connection.query(query,[req.body.firstname, req.body.lastname, req.body.Email1, req.body.password], function(err, rows, fields)
  {
      if (err)
     throw err;

  });
    res.redirect('/index.html')
    
});

});




router.post('/submit-rregister', (req, res) => {


   const  Rname= req.body.Rname
  const Biography = req.body.Biography

    const  Email1= req.body.Email1
  const password = req.body.password
  
    const password_confirm = req.body.password_confirm

    console.log('Restaurant name: ' + req.body.firstname);
   console.log('Biography: ' + req.body.lastname);


    console.log('Email: ' + req.body.Email1);
   console.log('password: ' + req.body.password);

  res.send(" Restaurant Name: " + Rname+ " Biography: " + Biography+ " Email: " + Email1+  " password: " + password + " password_confirm " + password_confirm)

});

router.post('/submit-account-details', (req, res) => {

   const  firstname= req.body.firstname
   const lastname = req.body.lastname
   const  Address= req.body.Address
   const  Phone= req.body.Phone
   const  Email= req.body.Email

  
  res.send(" First Name: " + firstname+ " Last Name: " + lastname+ " Email: " + Email+  " Address: " + Address + " Phone " + Phone)

});

router.post('/submit-restaurant-details', (req, res) => {

   const  Rname= req.body.Rname
   const  Address= req.body.Address
   const  Phone= req.body.Phone
   const  Email= req.body.Email
   const Tags = req.body.Tags
   const Location = req.body.Location
   const Biography=req.body.Biography


 const OpenM = req.body.OpenM
  const OpenTu = req.body.OpenTu
   const OpenW = req.body.OpenW
    const OpenTh = req.body.OpenTh
     const OpenF = req.body.OpenF
      const OpenSa = req.body.OpenSa
       const OpenSu = req.body.OpenSu

const CloseM = req.body.CloseM
  const CloseTu = req.body.CloseTu
   const CloseW = req.body.CloseW
    const CloseTh = req.body.CloseTh
     const CloseF = req.body.CloseF
      const CloseSa = req.body.CloseSa
       const CloseSu = req.body.CloseSu



        const OM = req.body.OM
  const OTu = req.body.OTu
   const OW = req.body.OW
    const OTh = req.body.OTh
     const OF = req.body.OF
      const OSa = req.body.OSa
       const OSu = req.body.OSu

const CM = req.body.CM
  const CTu = req.body.CTu
   const CW = req.body.CW
    const CTh = req.body.CTh
     const CF = req.body.CF
      const CSa = req.body.CSa
       const CSu = req.body.CSu






  
  res.send(" Name: " + Rname+ " Address: " + Address + " Phone " + Phone + " Email: " + Email + " Tags: " + Tags+ " Location: " + Location+ "Biography: " + Biography + 
    " OpenM: " + OpenM + " OpenTu: " + OpenTu + " OpenW: " + OpenW + " OpenTh: " + OpenTh + " OpenF: " + OpenF + " OpenSa: " + OpenSa + " OpenSu: " + OpenSu + " CloseM: " + CloseM + " CloseTu: " + CloseTu + " CloseW: " + CloseW + " CloseTh: " + CloseTh + " CloseF: " + CloseF + " CloseSa: " + CloseSa + " CloseSu: " + CloseSu +    " OM: " + OM + " OTu: " + OTu + " OW: " + OW + " OTh: " + OTh + " OF: " + OF + " OSa: " + OSa + " OSu: " + OSu + " CM: " + CM + " CTu: " + CTu + " CW: " + CW + " CTh: " + CTh + " CF: " + CF + " CSa: " + CSa + " CSu: " + CSu)

});



module.exports = router;