var express = require('express');
var path = require('path');
var router = express.Router();


/* GET home page. */
router.get('/', function(req, res, next) {
  res.render('index', { title: 'Express' });
});

router.get('/posts.json', function(req,res){
  

 req.pool.getConnection( function(err,connection) { 
 	if (err) {
 	throw err;
 	res.json({});
 }
 var username = req.query.username;
 var query = "SELECT date,contents "+"FROM users INNER JOIN blog_entries "+"ON users.user_id=blog_entries.author_id "+"WHERE users.username LIKE ?";
 connection.query(query, [username], function(err, rows, fields) {
  connection.release(); https://myuni.adelaide.edu.au/courses
  // release connection
  res.json(rows); //send response
 });});


router.post('/submit-booking', (req, res) => {

  const bookingdate = req.body.bookingdate
  const numSeats = req.body.numSeats

  
	console.log('date: ' + req.body.bookingdate);
 
   console.log('number of Seats: ' + req.body.numSeats);

  

  res.send(" date: "+ bookingdate+ " Number of seats " + numSeats)

});



router.post('/submit-login', (req, res) => {
  const Email = req.body.Email
  const Password = req.body.Password

  
	console.log('Email: ' + req.body.Email);
   console.log('Password: ' + req.body.Password);

  

  res.send(" Email: "+ Email+ " Password: " + Password)

});


router.post('/submit-register', (req, res) => {


   const  firstname= req.body.firstname
  const lastname = req.body.lastname

    const  Email1= req.body.Email1
  const password = req.body.password
  
    const password_confirm = req.body.password_confirm

   	console.log('firstname: ' + req.body.firstname);
   console.log('lastname: ' + req.body.lastname);


   	console.log('Email1: ' + req.body.Email1);
   console.log('password: ' + req.body.password);

  res.send(" First Name: " + firstname+ " Last Name: " + lastname+ " Email1: " + Email1+  " password: " + password + " password_confirm " + password_confirm)

});


router.post('/submit-rregister', (req, res) => {


   const  Rname= req.body.Rname
  const Biography = req.body.Biography

    const  Email1= req.body.Email1
  const password = req.body.password
  
    const password_confirm = req.body.password_confirm

    console.log('Restaurant name: ' + req.body.firstname);
   console.log('Biography: ' + req.body.lastname);


    console.log('Email: ' + req.body.Email1);
   console.log('password: ' + req.body.password);

  res.send(" Restaurant Name: " + Rname+ " Biography: " + Biography+ " Email: " + Email1+  " password: " + password + " password_confirm " + password_confirm)

});
module.exports = router;