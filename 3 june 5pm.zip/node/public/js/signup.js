function check_pass() {
    if (document.getElementById('password').value ==
            document.getElementById('password_confirm').value) {
        document.getElementById('submit').disabled = false;
    document.getElementById('message').innerHTML ='Password matching';
    document.getElementById('message').style.color = 'green';
    } else {
        document.getElementById('submit').disabled = true;
        document.getElementById('message').innerHTML ='Password not matching';
        document.getElementById('message').style.color = 'red';
    }
}
