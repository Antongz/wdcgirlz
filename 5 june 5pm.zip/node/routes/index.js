var express = require('express');
var path = require('path');
var router = express.Router();


/* GET home page. */
router.get('/', function(req, res, next) {
  res.render('index', { title: 'Express' });
});

/*router.get('/posts.json', function(req,res){
  

 req.pool.getConnection( function(err,connection) { 
 	if (err) {
 	throw err;
 	res.json({});
 }
 var username = req.query.username;
 var query = "SELECT date,contents "+"FROM users INNER JOIN blog_entries "+"ON users.user_id=blog_entries.author_id "+"WHERE users.username LIKE ?";
 connection.query(query, [username], function(err, rows, fields) {
  connection.release(); https://myuni.adelaide.edu.au/courses
  // release connection
  res.json(rows); //send response
 });});

*/
router.post('/submit-booking', (req, res) => {

  const bookingdate = req.body.bookingdate
  const numSeats = req.body.numSeats

  
	console.log('date: ' + req.body.bookingdate);
 
   console.log('number of Seats: ' + req.body.numSeats);

  

  res.send(" date: "+ bookingdate+ " Number of seats " + numSeats)

});

router.post('/submit-review', (req, res) => {

  const review = req.body.review
  
 
   console.log('Review: ' + req.body.review);  

  res.send(" Review: "+ review)

});



router.post('/submit-login', (req, res) => {
  const Email = req.body.Email
  const Password = req.body.Password

  
	console.log('Email: ' + req.body.Email);
   console.log('Password: ' + req.body.Password);

  

  res.send(" Email: "+ Email+ " Password: " + Password)

});


router.post('/submit-register', (req, res) => {


   const  firstname= req.body.firstname
  const lastname = req.body.lastname

    const  Email1= req.body.Email1
  const password = req.body.password
  
    const password_confirm = req.body.password_confirm

   	console.log('firstname: ' + req.body.firstname);
   console.log('lastname: ' + req.body.lastname);


   	console.log('Email1: ' + req.body.Email1);
   console.log('password: ' + req.body.password);

  res.send(" First Name: " + firstname+ " Last Name: " + lastname+ " Email1: " + Email1+  " password: " + password + " password_confirm " + password_confirm)

});


router.post('/submit-rregister', (req, res) => {


   const  Rname= req.body.Rname
  const Biography = req.body.Biography

    const  Email1= req.body.Email1
  const password = req.body.password
  
    const password_confirm = req.body.password_confirm

    console.log('Restaurant name: ' + req.body.firstname);
   console.log('Biography: ' + req.body.lastname);


    console.log('Email: ' + req.body.Email1);
   console.log('password: ' + req.body.password);

  res.send(" Restaurant Name: " + Rname+ " Biography: " + Biography+ " Email: " + Email1+  " password: " + password + " password_confirm " + password_confirm)

});

router.post('/submit-account-details', (req, res) => {

   const  firstname= req.body.firstname
   const lastname = req.body.lastname
   const  Address= req.body.Address
   const  Phone= req.body.Phone
   const  Email= req.body.Email

  
  res.send(" First Name: " + firstname+ " Last Name: " + lastname+ " Email: " + Email+  " Address: " + Address + " Phone " + Phone)

});

router.post('/submit-restaurant-details', (req, res) => {

   const  Rname= req.body.Rname
   const  Address= req.body.Address
   const  Phone= req.body.Phone
   const  Email= req.body.Email
      const Tags = req.body.Tags
   const Location = req.body.Location
   const Biography=req.body.Biography


 const OpenM = req.body.OpenM
  const OpenTu = req.body.OpenTu
   const OpenW = req.body.OpenW
    const OpenTh = req.body.OpenTh
     const OpenF = req.body.OpenF
      const OpenSa = req.body.OpenSa
       const OpenSu = req.body.OpenSu

const CloseM = req.body.CloseM
  const CloseTu = req.body.CloseTu
   const CloseW = req.body.CloseW
    const CloseTh = req.body.CloseTh
     const CloseF = req.body.CloseF
      const CloseSa = req.body.CloseSa
       const CloseSu = req.body.CloseSu



        const OM = req.body.OM
  const OTu = req.body.OTu
   const OW = req.body.OW
    const OTh = req.body.OTh
     const OF = req.body.OF
      const OSa = req.body.OSa
       const OSu = req.body.OSu

const CM = req.body.CM
  const CTu = req.body.CTu
   const CW = req.body.CW
    const CTh = req.body.CTh
     const CF = req.body.CF
      const CSa = req.body.CSa
       const CSu = req.body.CSu






  
  res.send(" Name: " + Rname+ " Address: " + Address + " Phone " + Phone + " Email: " + Email + " Tags: " + Tags+ " Location: " + Location+ "Biography: " + Biography + 
    " OpenM: " + OpenM + " OpenTu: " + OpenTu + " OpenW: " + OpenW + " OpenTh: " + OpenTh + " OpenF: " + OpenF + " OpenSa: " + OpenSa + " OpenSu: " + OpenSu + " CloseM: " + CloseM + " CloseTu: " + CloseTu + " CloseW: " + CloseW + " CloseTh: " + CloseTh + " CloseF: " + CloseF + " CloseSa: " + CloseSa + " CloseSu: " + CloseSu +    " OM: " + OM + " OTu: " + OTu + " OW: " + OW + " OTh: " + OTh + " OF: " + OF + " OSa: " + OSa + " OSu: " + OSu + " CM: " + CM + " CTu: " + CTu + " CW: " + CW + " CTh: " + CTh + " CF: " + CF + " CSa: " + CSa + " CSu: " + CSu)

});



module.exports = router;