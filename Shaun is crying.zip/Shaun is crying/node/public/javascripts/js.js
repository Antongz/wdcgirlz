function getSignUp() {
	//create AJAX request 
	var xhttp = new XMLHttpRequest();

	xhttp.open("GET", "/signup", true);
	xhttp.send();

}