var express = require('express');
var path = require('path');
var router = express.Router();


/* GET home page. */
router.get('/', function(req, res, next) {
  res.render('index', { title: 'Express' });
});

// req.pool.getConnection( function(err,connection) { 
// 	if (err) {
// 	throw err;
// 	res.json({});
// }
// var username = req.query.username;
// var query = "SELECT date,contents "+"FROM users INNER JOIN blog_entries "+"ON users.user_id=blog_entries.author_id "+"WHERE users.username LIKE ?";
// connection.query(query, [username], function(err, rows, fields) {
//  connection.release(); https://myuni.adelaide.edu.au/courses
//  // release connection
//  res.json(rows); //send response
// });});

module.exports = router;
