function getPosts() {

// Get username input
var input = document.getElementById('username');

// Create AJAX request
var blogRequest = new XMLHttpRequest();

// What to do when AJAX response comes
blogRequest.onreadystatechange = function() {
	if (blogRequest.readyState==4 && blogRequest.status==200) {

		// get posts div and clear it
		var posts_div = document.getElementById('posts');
		while (posts_div.hasChildNodes()) {
		posts_div.removeChild(posts_div.childNodes[0]);
		}

		// although we sent JSON, XMLHttpRequest only 
		// handles text and xml so we need to parse it
		var result = JSON.parse(blogRequest.response);

		// create new blogpost entries
		for (var i = 0; i < result.length; i++) {
			var current_post = document.createElement("DIV");
			current_post.innerHTML = '<p>'+new Date(result[i].date)+'</p>\n<p>'+result[i].contents+'</p>\n<hr>';
			posts_div.appendChild(current_post);
			}}}

	// Open connectionb
	blogRequest.open("GET",'http://localhost:3000/posts.json?username='+input.value,true);

	// Send request
	blogRequest.send();
}

