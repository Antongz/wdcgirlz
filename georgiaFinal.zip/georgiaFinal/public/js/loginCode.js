
        function login()
        {

            var xhttp = new XMLHttpRequest();
            xhttp.onreadystatechange = function()
            {

                if(this.readyState==4 && this.status==200)
                {
                    alert("welcome");
                    window.location.pathname = "index.html";
                }

                else if(this.readyState==4 && this.status==403)
                {
                    alert("Username/Incorrect password");
                }

            };


            xhttp.open("POST", "/submit-login", true);
            xhttp.setRequestHeader('Content-Type', 'application/json');
            xhttp.send(JSON.stringify({email:document.getElementById('email').value, pass:document.getElementById('pass').value}));



        }