function searchButton(){

            var input = document.getElementByClass('btn-group1');
            var resultsRequest = new XMLHttpRequest();

            resultsRequest.onreadystatechange = function() {
                if (resultsRequest.readyState == 4 && resultsRequest.status == 200) {
                    var posts_div = document.getElementById('posts');
                    while(posts_div.hasChildNodes()) {
                    	posts_div.removeChild(posts_div.childNodes[0]);
                }

                var result = JSON.parse(resultsRequest.response);

                for(var i=0; i<result.length; i++){
                	var current_post = document.createElement("DIV");
                	current_post.innerHTML = '<p>'+ result[i].cuisine+'</p>\n<hr>';
                	posts_div.appendChild(current_post);
                }
            }
	        }

	        resultsRequest.open("GET",'http://localhost:3000/posts.json?cuisine='+input.value,true);

	        resultsRequest.send();
	    }