var createError = require('http-errors');
var express = require('express');
var path = require('path');
var cookieParser = require('cookie-parser');
var session = require('express-session');
var logger = require('morgan');
var mysql = require('mysql');

var indexRouter = require('./routes/index');
var usersRouter = require('./routes/users');

var app = express();

var dbConnectionPool = mysql.createPool({ host: '127.0.0.1',database: 'the_spoon'});




// app.get('/', function(req, res){
// 	//about mysql
// 	connection.query("SELECT * FROM Restaurant", function(error, rows, fields){
// 		if(!!error){
// 			console.log('Error in the query');
// 		}else {
// 			console.log('Successful query'); 
// 			console.log(rows[0].Name);
// 			resp.json(rows[0].Name);
// 		}
// 	});
// });

app.listen(1337);


// view engine setup
app.set('views', path.join(__dirname, 'views'));
app.set('view engine', 'jade');

app.use(logger('dev'));
app.use(express.json());
app.use(express.urlencoded({ extended: false }));
app.use(cookieParser());

//app.use session
//create session middleware to handle sessions in app.js
//secret string of choice
app.use(session({
	secret: 'abcdefgh',
	resave: false,
	saveUninitialized: true,
	cookie: {secure:false}
}));

/*
	using sessions:
	-session middleware will automatically create session middleware for you and store info in variable req.session
	-can set and read session variables using req.session in your routes in index.js

	req.session.variableName = 5;
	console.log(req.session.variableName);

	//so on server sie
	//can use req.session.something
	-set variable name on sessions
	-session data will persits on server as soon as data is running



*/


app.use(express.static(path.join(__dirname, 'public')));

app.use(function(req, res, next) { 
	req.pool = dbConnectionPool; 
	next(); 
});

app.use('/', indexRouter);
app.use('/users', usersRouter);


// catch 404 and forward to error handler
app.use(function(req, res, next) {
  next(createError(404));
});

// error handler
app.use(function(err, req, res, next) {
  // set locals, only providing error in development
  res.locals.message = err.message;
  res.locals.error = req.app.get('env') === 'development' ? err : {};

  // render the error page
  res.status(err.status || 500);
  res.render('error');
});



module.exports = app;