var express = require('express');
var path = require('path');
var router = express.Router();

var mysql = require('mysql');



var connection = mysql.createConnection( {
  //properties
  host:'localhost',
  user: 'root',
  password: '',
  database: 'the_spoon'
});
/* GET home page. */
router.get('/', function(req, res, next) {
  res.render('index', { title: 'Express' });
});


router.get('/results.json', function(req, res, next) {

  var cuisine = "Thai";
  var location = req.body.location;

  console.log('Cuisine ' + req.query.cuisine);
  console.log('Location ' + req.body.location);

  var query = "SELECT Name, locations, phone_number, email_address, cuisine FROM Restaurant WHERE cuisine LIKE ?";
  connection.query(query, [cuisine], function(error, rows, fields){
      if(!!error){
        console.log('Error in query')
      } else{
        console.log('Successful query'); 
       console.log(rows);
       console.log(req.body.cuisine);
       res.json(rows);
      }   
  });
});

router.get('/japanese.json', function(req, res, next){
  var Jap = "Japanese";

  var query = "SELECT Name, locations, phone_number, email_address, cuisine FROM Restaurant WHERE cuisine LIKE ?";
  connection.query(query, [Jap], function(error, rows, fields){
    if(!!error){
      console.log('Error in query');
    } else {
      res.json(rows);
    }
  });
});

router.get('/thai.json', function(req, res, next){
  var thai = "Thai";

  var query = "SELECT Name, locations, phone_number, email_address, cuisine FROM Restaurant WHERE cuisine LIKE ?";
  connection.query(query, [thai], function(error, rows, fields){
    if(!!error){
      console.log('Error in query');
    } else {
      res.json(rows);
    }
  });
});

router.get('/european.json', function(req, res, next){
  var eur = "European";

  var query = "SELECT Name, locations, phone_number, email_address, cuisine FROM Restaurant WHERE cuisine LIKE ?";
  connection.query(query, [eur], function(error, rows, fields){
    if(!!error){
      console.log('Error in query');
    } else {
      res.json(rows);
    }
  });
});

router.get('/fast-food.json', function(req, res, next){
  var FF = "Fast Food";

  var query = "SELECT Name, locations, phone_number, email_address, cuisine FROM Restaurant WHERE cuisine LIKE ?";
  connection.query(query, [FF], function(error, rows, fields){
    if(!!error){
      console.log('Error in query');
    } else {
      res.json(rows);
    }
  });
});

router.get('/allResults.json', function(req, res, next){

  var query = "SELECT Name, locations, phone_number, email_address, cuisine FROM Restaurant";
   connection.query(query,function(error, rows, fields){
    if(!!error){
      console.log('Error in query');
    } else {
      res.json(rows);
    }
  });
});


router.post('/submit-review', (req, res) => {


  const title = req.body.title
  const content = req.body.content
  const created_time = new Date();
  
  console.log('title: ' + req.body.title);  

   console.log('Content: ' + req.body.content);

      console.log('time: ' + req.body.created_time);  


    connection.query("INSERT INTO reviewpost (title, content) VALUES ('"+req.body.title+"','"+req.body.content+"')",function(err, result)      
{                                                      
  if (err)
     throw err;
});


res.redirect('/detail.html')
});


//Login for Customer
router.post('/submit-login', function(req, res,next) {
  req.pool.getConnection(function(err,connection)
  {

    if(err)
    {
      res.sendStatus(402);
      console.log(err.message)
    }

    var query = "SELECT first_name FROM Customer WHERE email_address = ? AND password = SHA2(?, 256)";
    //var query = "SELECT first_name FROM Customer WHERE email_address = ? AND password = ?";

    connection.query(query,[req.body.email, req.body.pass], function(err, rows, fields)
    {
      connection.release(); //release connection
      console.log(rows);

      if(rows.length>0)
      {
        req.session.userid = rows[0].first_name;
        res.send(rows[0].first_name);
      }

      else
      {
        res.sendStatus(403);
      }

    });



  });

});


router.post('/checkSession', function(req, res, next) {


  if('userid' in req.session){

    console.log(req.session.userid);

    //connect to the database:
    req.pool.getConnection(function(err, connection)
    {

      if(err)
      {
        res.sendStatus(402);
      }

      var query = "SELECT first_name FROM Customer WHERE email_address =?"

      connection.query(query,[req.session.userid], function(err, rows, fields)
      {

        connection.release();
        console.log(rows);
        console.log(req.session.userid);
        res.sendStatus(200);

        // res.redirect('/');

      });


    });

  }

  else
  {
    console.log("not logged in");
    // res.redirect('/login.html')

  }

});



router.post('/signOut', function(req, res, next) {

  if('userid' in req.session){

    console.log(req.session.userid);

    //connect to the database:
    req.pool.getConnection(function(err, connection)
    {

      if(err)
      {
        res.sendStatus(402);
      }

      //destroy session
      res.sendStatus(200);
      req.session.destroy();

    });

  }

  else
  {

    console.log("not working");
    res.sendStatus(403);

  }


});



//Login for Restaurant
router.post('/submit-llogin', function(req, res,next) {
  req.pool.getConnection(function(err,connection)
  {

    if(err)
    {
      res.sendStatus(402);
      console.log(err.message)
    }

    var query = "SELECT Name FROM Restaurant WHERE email_address = ? AND password = SHA2(?, 256)";
    //var query = "SELECT first_name FROM Customer WHERE email_address = ? AND password = ?";

    connection.query(query,[req.body.email, req.body.pass], function(err, rows, fields)
    {
      connection.release(); //release connection
      console.log(rows);

      if(rows.length>0)
      {
        req.session.userid = rows[0].Name;
        res.send(rows[0].Name);
      }

      else
      {
        res.sendStatus(403);
      }

    });



  });

});




router.post('/submit-register', (req, res) => {

  const  firstname= req.body.firstname
  const lastname = req.body.lastname
  const  Email1= req.body.Email1
  const password = req.body.password
  const password_confirm = req.body.password_confirm


  connection.query("INSERT INTO Customer (first_name, last_name, password, email_address) VALUES ('"+req.body.firstname+"','"+req.body.lastname+"','"+req.body.password+"','"+req.body.Email1+"')",function(err, result)      
{                                                      
  if (err)
     throw err;
});

  res.redirect('/index.html')
});


router.post('/submit-register', function(req, res, next) {

  req.pool.getConnection(function(err,connection)
  {

    if(err)
    {
      res.sendStatus(402);
      console.log(err.message)
    }

  
  var query = "INSERT INTO Customer(first_name, last_name, email_address, password) VALUES (?, ? , ?, SHA2(?,256))";

//SHA2(?,256)

  connection.query(query,[req.body.firstname, req.body.lastname, req.body.Email1, req.body.password], function(err, rows, fields)
  {
      if (err)
     throw err;

  });
    res.redirect('/index.html')
    
});

});


router.post('/submit-rregister', function(req, res, next) {

  req.pool.getConnection(function(err,connection)
  {

    if(err)
    {
      res.sendStatus(402);
      console.log(err.message);
    }

  
  var query = "INSERT INTO Restaurant(email_address, Name, locations, password) VALUES (?, ? , ?, ?, SHA2(?,256))";

  
  connection.query(query,[req.body.Email1, req.body.Rname1, req.body.Location, req.body.password], function(err, rows, fields)
  {
      if (err) {
        res.sendStatus(402);
        console.log(err.message);
      }
     

  });
    res.redirect('/index.html')
    
    
});

});


router.post('/submit-account-details', (req, res) => {

   const  firstname= req.body.firstname
   const lastname = req.body.lastname
   const  Address= req.body.Address
   const  Phone= req.body.Phone
   const  Email= req.body.Email

  
  res.send(" First Name: " + firstname+ " Last Name: " + lastname+ " Email: " + Email+  " Address: " + Address + " Phone " + Phone)

});

router.post('/submit-restaurant-details', (req, res) => {

   const  Rname= req.body.Rname
   const  Address= req.body.Address
   const  Phone= req.body.Phone
   const  Email= req.body.Email
   const Tags = req.body.Tags
   const Location = req.body.Location


 const OpenM = req.body.OpenM
  const OpenTu = req.body.OpenTu
   const OpenW = req.body.OpenW
    const OpenTh = req.body.OpenTh
     const OpenF = req.body.OpenF
      const OpenSa = req.body.OpenSa
       const OpenSu = req.body.OpenSu

const CloseM = req.body.CloseM
  const CloseTu = req.body.CloseTu
   const CloseW = req.body.CloseW
    const CloseTh = req.body.CloseTh
     const CloseF = req.body.CloseF
      const CloseSa = req.body.CloseSa
       const CloseSu = req.body.CloseSu



        const OM = req.body.OM
  const OTu = req.body.OTu
   const OW = req.body.OW
    const OTh = req.body.OTh
     const OF = req.body.OF
      const OSa = req.body.OSa
       const OSu = req.body.OSu

const CM = req.body.CM
  const CTu = req.body.CTu
   const CW = req.body.CW
    const CTh = req.body.CTh
     const CF = req.body.CF
      const CSa = req.body.CSa
       const CSu = req.body.CSu

  
  res.send(" Name: " + Rname+ " Address: " + Address + " Phone " + Phone + " Email: " + Email + " Tags: " + Tags+ " Location: " + Location+
    " OpenM: " + OpenM + " OpenTu: " + OpenTu + " OpenW: " + OpenW + " OpenTh: " + OpenTh + " OpenF: " + OpenF + " OpenSa: " + OpenSa + " OpenSu: " + OpenSu + " CloseM: " + CloseM + " CloseTu: " + CloseTu + " CloseW: " + CloseW + " CloseTh: " + CloseTh + " CloseF: " + CloseF + " CloseSa: " + CloseSa + " CloseSu: " + CloseSu +    " OM: " + OM + " OTu: " + OTu + " OW: " + OW + " OTh: " + OTh + " OF: " + OF + " OSa: " + OSa + " OSu: " + OSu + " CM: " + CM + " CTu: " + CTu + " CW: " + CW + " CTh: " + CTh + " CF: " + CF + " CSa: " + CSa + " CSu: " + CSu)

});

const fs = require('fs');
const readline = require('readline');
const {google} = require('googleapis');

// If modifying these scopes, delete token.json.
const SCOPES = ['https://www.googleapis.com/auth/calendar'];
// The file token.json stores the user's access and refresh tokens, and is
// created automatically when the authorization flow completes for the first
// time.
const TOKEN_PATH = 'token.json';


router.post('/submit-booking', (req, res) => {

  const bookingDate = req.body.bookingDate
  const numSeats = req.body.numSeats
  
  console.log('date: ' + req.body.bookingdate);
 
  console.log('number of Seats: ' + req.body.numSeats);

  res.send(" date: "+ bookingDate+ " Number of seats " + numSeats)

   connection.query("INSERT INTO Bookings (email_address, booking_date, num_seats) VALUES ('lottie.minney@gmail.com','"+req.body.bookingDate+"','"+req.body.numSeats+"')",function(err, result)      
  {                                                      
  if (err)
     throw err;
  });

   // Load client secrets from a local file.
fs.readFile('credentials.json', (err, content) => {
  if (err) return console.log('Error loading client secret file:', err);
  // Authorize a client with credentials, then call the Google Calendar API.
  authorize(JSON.parse(content), addEvents);
  });
});

/**
 * Create an OAuth2 client with the given credentials, and then execute the
 * given callback function.
 * @param {Object} credentials The authorization client credentials.
 * @param {function} callback The callback to call with the authorized client.
 */
function authorize(credentials, callback) {
  const {client_secret, client_id, redirect_uris} = credentials.installed;
  const oAuth2Client = new google.auth.OAuth2(
      client_id, client_secret, redirect_uris[0]);

  // Check if we have previously stored a token.
  fs.readFile(TOKEN_PATH, (err, token) => {
    if (err) return getAccessToken(oAuth2Client, callback);
    oAuth2Client.setCredentials(JSON.parse(token));
    callback(oAuth2Client);
  });
}

/**
 * Get and store new token after prompting for user authorization, and then
 * execute the given callback with the authorized OAuth2 client.
 * @param {google.auth.OAuth2} oAuth2Client The OAuth2 client to get token for.
 * @param {getEventsCallback} callback The callback for the authorized client.
 */
function getAccessToken(oAuth2Client, callback) {
  const authUrl = oAuth2Client.generateAuthUrl({
    access_type: 'offline',
    scope: SCOPES,
  });
  console.log('Authorize this app by visiting this url:', authUrl);
  const rl = readline.createInterface({
    input: process.stdin,
    output: process.stdout,
  });
  rl.question('Enter the code from that page here: ', (code) => {
    rl.close();
    oAuth2Client.getToken(code, (err, token) => {
      if (err) return console.error('Error retrieving access token', err);
      oAuth2Client.setCredentials(token);
      // Store the token to disk for later program executions
      fs.writeFile(TOKEN_PATH, JSON.stringify(token), (err) => {
        if (err) return console.error(err);
        console.log('Token stored to', TOKEN_PATH);
      });
      callback(oAuth2Client);
    });
  });
}

/**
 * Lists the next 10 events on the user's primary calendar.
 * @param {google.auth.OAuth2} auth An authorized OAuth2 client.
 */
function listEvents(auth) {
  const calendar = google.calendar({version: 'v3', auth});
  calendar.events.list({
    calendarId: 'primary',
    timeMin: (new Date()).toISOString(),
    maxResults: 10,
    singleEvents: true,
    orderBy: 'startTime',
  }, (err, res) => {
    if (err) return console.log('The API returned an error: ' + err);
    const events = res.data.items;
    if (events.length) {
      console.log('Upcoming 10 events:');
      events.map((event, i) => {
        const start = event.start.dateTime || event.start.date;
        console.log(`${start} - ${event.summary}`);
      });
    } else {
      console.log('No upcoming events found.');
    }
  });
}

function addEvents(auth){

var event = {
  "summary": "Dinner Reservation at Danny's Thai",
  "location": "123A The Parade, Norwood SA 5067",
  "start": {
    "dateTime": "2019-06-13T10:00:00-00:00",
    "timeZone": "America/Los_Angeles",
  },
  "end": {
    "dateTime": "2019-06-13T12:00:00-00:00",
    "timeZone": "America/Los_Angeles",
  },
  "reminders": {
    "useDefault": true,
  },
};

var calendar = google.calendar("v3");
calendar.events.insert({
  auth: auth,
  calendarId: "primary",
  resource: event,
}, function(err, event) {
  if (err) {
    console.log("There was an error contacting the Calendar service: " + err);
    return;
  }
  console.log("Event created: %s", event.data.htmlLink);
});

}



module.exports = router;