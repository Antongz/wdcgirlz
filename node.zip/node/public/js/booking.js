function check_bookingDate() {

var dateinput = new Date(document.getElementById("date").value);
var datecurrent = new Date();

 if(dateinput> datecurrent){
    document.getElementById('submit').disabled = false;
    document.getElementById('message').innerHTML ='Date Available';
    document.getElementById('message').style.color = 'green';
    } else if (dateinput < datecurrent){
        document.getElementById('submit').disabled = true;
        document.getElementById('message').innerHTML =' Date unAvailable';
        document.getElementById('message').style.color = 'red';
        
    } else if (dateinput === datecurrent){
         document.getElementById('submit').disabled = false;
    document.getElementById('message').innerHTML ='Date Available';
    document.getElementById('message').style.color = 'green';
    }
}





